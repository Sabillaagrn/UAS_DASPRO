import java.util.Scanner;
import Controller.PerpusController;

public class App {
    public static void main(String[] args) throws Exception {
        PerpusController perpusController = new PerpusController();
        perpusController.bookList();
        Scanner scanner = new Scanner(System.in);

        System.out.println("==PERPUSTAKAAN UIN BANDUNG==");
        perpusController.login(scanner);
    }
        


}