package Controller;

import java.util.Scanner;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

import java.util.Map;


//Import model classes
import model.Admin;
import model.Data;
import model.Peminjam;
import model.Peminjaman;
import model.Data.Buku;

public class PerpusController {
    Scanner scanner = new Scanner(System.in);
    HashMap<String, Buku> bukus = new HashMap<>();
    HashMap<String, Peminjam> peminjams = new HashMap<>();
    HashMap<String, Admin> admins = new HashMap<>();
    ArrayList<Peminjaman> peminjamans = new ArrayList<>();
    private Peminjam peminjamAktif; // Untuk menyimpan informasi peminjam yang sedang aktif
    private HashMap<Integer, String> klasifikasiMap = new HashMap<>();

    public void bookList(){
        Data data = new Data();
        //Karya Umum
            Data.Buku buku1 = data.new Buku();
            Data.Buku buku2 = data.new Buku();
            Data.Buku buku3 = data.new Buku();
            Data.Buku buku4 = data.new Buku();
            Data.Buku buku5 = data.new Buku();
            buku1.setJudulBuku ("The Subtle Art of Not Giving a F*ck")
                .setPenulis ("Mark Manson")
                .setKlasifikasi (1)
                .setNoInv("1.1")
                .setTersedia (true);
            buku2.setJudulBuku ("Rich Dad Poor Dad")
                .setPenulis ("Robert T. Kiyosaki")
                .setKlasifikasi (1)
                .setNoInv("1.2")
                .setTersedia (true);
            buku3.setJudulBuku ("The 5 Level of Leadership")
                .setPenulis ("John C. Maxwell")
                .setKlasifikasi (1)
                .setNoInv("1.3")
                .setTersedia (true);
            buku4.setJudulBuku ("Crushing It!: How Great Entrepreneurs Build Their Business and Influence-and How You Can, Too")
                .setPenulis ("Gary Vaynerchuk")
                .setKlasifikasi (1)
                .setNoInv("1.4")
                .setTersedia (true);
            buku5.setJudulBuku ("Bung Karno: Penyambung Lidah Rakyat Indonesia")
                .setPenulis ("Cindy Adams")
                .setKlasifikasi (1)
                .setNoInv("1.5")
                .setTersedia (true);               
            bukus.put(buku1.getNoInv(),buku1);
            bukus.put(buku2.getNoInv(),buku2);
            bukus.put(buku3.getNoInv(),buku3);
            bukus.put(buku4.getNoInv(),buku4);
            bukus.put(buku5.getNoInv(),buku5);

            //Filsafat
            Data.Buku buku6 = data.new Buku();
            Data.Buku buku7 = data.new Buku();
            Data.Buku buku8 = data.new Buku();
            Data.Buku buku9 = data.new Buku();
            Data.Buku buku10 = data.new Buku();
            buku6.setJudulBuku ("Filosofi Teras: Filsafat Yunani-Romawi Kuno untuk Mental Tangguh Masa Kini")
                .setPenulis ("Henry Manampiring")
                .setKlasifikasi (2)
                .setNoInv("2.1")
                .setTersedia (true);
            buku7.setJudulBuku ("Feminisme Islam: Genealogi, Tantangan, dan Prospek")
                .setPenulis ("Etin Anwar")
                .setKlasifikasi (2)
                .setNoInv("2.2")
                .setTersedia (true);
            buku8.setJudulBuku ("Menghilang, Menemukan Diri Sejati")
                .setPenulis ("Fahruddin Faiz")
                .setKlasifikasi (2)
                .setNoInv("2.3")
                .setTersedia (true);
            buku9.setJudulBuku ("Pengantar Filsafat")
                .setPenulis ("K. Bertens, Johanes Ohoitimur, and Mikhael Dua")
                .setKlasifikasi (2)
                .setNoInv("2.4")
                .setTersedia (true);
            buku10.setJudulBuku ("Fihi Ma Fihi")
                .setPenulis ("Jalaluddin Rumi")
                .setKlasifikasi (2)
                .setNoInv("2.5")
                .setTersedia (true); 
                bukus.put(buku6.getNoInv(),buku6);
                bukus.put(buku7.getNoInv(),buku7);
                bukus.put(buku8.getNoInv(),buku8);
                bukus.put(buku9.getNoInv(),buku9);
                bukus.put(buku10.getNoInv(),buku10);

            //Ilmu Sosial
            Data.Buku buku11 = data.new Buku();
            Data.Buku buku12 = data.new Buku();
            Data.Buku buku13 = data.new Buku();
            Data.Buku buku14 = data.new Buku();
            Data.Buku buku15 = data.new Buku();
            buku11.setJudulBuku ("Ilmu Budaya Dasar Social Culture")
                .setPenulis ("Munandar Sulaeman")
                .setKlasifikasi (3)
                .setNoInv("3.1")
                .setTersedia (true);
            buku12.setJudulBuku ("Manusia Kebudayaan & Masyarakat : Ilmu Sosial Budaya Dasar")
                .setPenulis ("Urbanus Ura Weruin")
                .setKlasifikasi (3)
                .setNoInv("3.2")
                .setTersedia (true);
            buku13.setJudulBuku ("Sosiologi Suatu Pengantar Edisi Revisi")
                .setPenulis ("Soerjono Soekanto")
                .setKlasifikasi (3)
                .setNoInv("3.3")
                .setTersedia (true);
            buku14.setJudulBuku ("Sosiologi Perubahan Sosial")
                .setPenulis ("Soerjono Soekanto")
                .setKlasifikasi (3)
                .setNoInv("3.4")
                .setTersedia (true);
            buku15.setJudulBuku ("Imajinasi Sosiologi Pembangunan Sosietal")
                .setPenulis ("Paulus Wirutomo")
                .setKlasifikasi (3)
                .setNoInv("3.5")
                .setTersedia (true); 
                bukus.put(buku11.getNoInv(),buku11);
                bukus.put(buku12.getNoInv(),buku12);
                bukus.put(buku13.getNoInv(),buku13);
                bukus.put(buku14.getNoInv(),buku14);
                bukus.put(buku15.getNoInv(),buku15);

            //Bahasa
            Data.Buku buku16 = data.new Buku();
            Data.Buku buku17 = data.new Buku();
            Data.Buku buku18 = data.new Buku();
            Data.Buku buku19 = data.new Buku();
            Data.Buku buku20 = data.new Buku();
            buku16.setJudulBuku("Bumi Manusia")
                .setPenulis ("Pramoedya Ananta Toer")
                .setKlasifikasi (4)
                .setNoInv("4.1")
                .setTersedia (true); 
             buku17.setJudulBuku("Laskar Pelangi")
                .setPenulis ("Andrea Hirata")
                .setKlasifikasi (4)
                .setNoInv("4.2")
                .setTersedia (true);
            buku18.setJudulBuku("Anak Semua Bangsa")
                .setPenulis ("Pramoedya Ananta Toer")
                .setKlasifikasi (4)
                .setNoInv("4.3")
                .setTersedia (true); 
            buku19.setJudulBuku("Ronggeng Dukuh Paruk")
                .setPenulis ("Ahmad Tohari")
                .setKlasifikasi (4)
                .setNoInv("4.4")
                .setTersedia (true);    
            buku20.setJudulBuku("Negeri 5 Menara")
                .setPenulis (" Ahmad Fuadi ")
                .setKlasifikasi (4)
                .setNoInv("4.5")
                .setTersedia (true);    
                bukus.put(buku16.getNoInv(),buku16);
                bukus.put(buku17.getNoInv(),buku17);
                bukus.put(buku18.getNoInv(),buku18);
                bukus.put(buku19.getNoInv(),buku19);
                bukus.put(buku20.getNoInv(),buku20);

            //Ilmu Murni
            Data.Buku buku21 = data.new Buku();
            Data.Buku buku22 = data.new Buku();
            Data.Buku buku23 = data.new Buku();
            Data.Buku buku24 = data.new Buku();
            Data.Buku buku25 = data.new Buku();
            buku21.setJudulBuku("The Universe In A Nutshell")
                .setPenulis ("Stephen Hawking")
                .setKlasifikasi (5)
                .setNoInv("5.1")
                .setTersedia (true);  
            buku22.setJudulBuku("A Brief History Of Time")
                .setPenulis ("Stephen Hawking")
                .setKlasifikasi (5)
                .setNoInv("5.2")
                .setTersedia (true);  
            buku23.setJudulBuku("The Art of Drug Synthesis")
                .setPenulis ("Douglas S. Johnson")
                .setKlasifikasi (5)
                .setNoInv("5.3")
                .setTersedia (true);  
            buku24.setJudulBuku("An Introduction to Genetic Engineering")
                .setPenulis ("Desmond S.T. Nicholl")
                .setKlasifikasi (5)
                .setNoInv("5.4")
                .setTersedia (true);  
            buku25.setJudulBuku("Battery Technology : From Fundamentals To Thermalr and Managementt")
                .setPenulis ("Marc A Rosen")
                .setKlasifikasi (5)
                .setNoInv("5.5")
                .setTersedia (true); 
                bukus.put(buku21.getNoInv(),buku21);
                bukus.put(buku22.getNoInv(),buku22);
                bukus.put(buku23.getNoInv(),buku23);
                bukus.put(buku24.getNoInv(),buku24);
                bukus.put(buku25.getNoInv(),buku25);

            //Pengetahuan Praktis
            Data.Buku buku26 = data.new Buku();
            Data.Buku buku27 = data.new Buku();
            Data.Buku buku28 = data.new Buku();
            Data.Buku buku29 = data.new Buku();
            Data.Buku buku30 = data.new Buku();
            buku26.setJudulBuku("Sapiens")
                .setPenulis ("Yuval Noah Harari")
                .setKlasifikasi (6)
                .setNoInv("6.1")
                .setTersedia (true); 
            buku27.setJudulBuku("Homo Deus")
                .setPenulis ("Yuval Noah Harari")
                .setKlasifikasi (6)
                .setNoInv("6.2")
                .setTersedia (true);
            buku28.setJudulBuku("Guns, Germs, and Steel")
                .setPenulis ("Jared Diamond")
                .setKlasifikasi (6)
                .setNoInv("6.3")
                .setTersedia (true); 
            buku29.setJudulBuku("Cosmos")
                .setPenulis("Carl Sagan")
                .setKlasifikasi (6)
                .setNoInv("6.4")
                .setTersedia (true); 
            buku30.setJudulBuku("KEPERAWATAN GERONTIK Pengetahuan Praktis Bagi Perawat")
                .setPenulis (" ")
                .setKlasifikasi (6)
                .setNoInv("6.5")
                .setTersedia (true);
                bukus.put(buku26.getNoInv(),buku26);
                bukus.put(buku27.getNoInv(),buku27);
                bukus.put(buku28.getNoInv(),buku28);
                bukus.put(buku29.getNoInv(),buku29);
                bukus.put(buku30.getNoInv(),buku30);

                //Kesenian dan Hiburan
                Data.Buku buku31 = data.new Buku();
                Data.Buku buku32 = data.new Buku();
                Data.Buku buku33 = data.new Buku();
                Data.Buku buku34 = data.new Buku();
                Data.Buku buku35 = data.new Buku();
            buku31.setJudulBuku ("A Sense of Direction: Some Observations on the Art of Directing")
                .setPenulis ("William Ball")
                .setKlasifikasi (7)
                .setNoInv("7.1")
                .setTersedia (true);
            buku32.setJudulBuku ("Right on Cue")
                .setPenulis ("Falon Ballard")
                .setKlasifikasi (7)
                .setNoInv("7.2")
                .setTersedia (true);
            buku33.setJudulBuku ("Expiration Dates")
                .setPenulis ("Rebecca Serle")
                .setKlasifikasi (7)
                .setNoInv("7.3")
                .setTersedia (true);
            buku34.setJudulBuku ("The Three Dahlias")
                .setPenulis ("Katy Watson")
                .setKlasifikasi (7)
                .setNoInv("7.4")
                .setTersedia (true);
            buku35.setJudulBuku ("Picasso’s War: How Modern Art Came to America")
                .setPenulis ("Hugh Eakin")
                .setKlasifikasi (7)
                .setNoInv("7.5")
                .setTersedia (true);
                bukus.put(buku31.getNoInv(),buku31);
                bukus.put(buku32.getNoInv(),buku32);
                bukus.put(buku33.getNoInv(),buku33);
                bukus.put(buku34.getNoInv(),buku34);
                bukus.put(buku35.getNoInv(),buku35);

                //Kesusastraan
                Data.Buku buku36 = data.new Buku();
                Data.Buku buku37 = data.new Buku();
                Data.Buku buku38 = data.new Buku();
                Data.Buku buku39 = data.new Buku();
                Data.Buku buku40 = data.new Buku();
            buku36.setJudulBuku ("Bumi Manusia")
                .setPenulis ("Pramoedya Ananta Toer")
                .setKlasifikasi (8)
                .setNoInv("8.1")
                .setTersedia (true);    
            buku37.setJudulBuku ("Laskar Pelangi")
                .setPenulis ("Andrea Hirata")
                .setKlasifikasi (8)
                .setNoInv("8.2")
                .setTersedia (true);   
            buku38.setJudulBuku ("Anak Semua Bangsa")
                .setPenulis ("Pramoedya Ananta Toer")
                .setKlasifikasi (8)
                .setNoInv("8.3")
                .setTersedia (true);
            buku39.setJudulBuku ("Ronggeng Dukuh Paruk")
                .setPenulis ("Ahmad Tohari")
                .setKlasifikasi (8)
                .setNoInv("8.4")
                .setTersedia (true);
            buku40.setJudulBuku ("Negeri 5 Menara")
                .setPenulis ("Ahmad Fuadi")
                .setKlasifikasi (8)
                .setNoInv("8.5")
                .setTersedia (true);
                bukus.put(buku36.getNoInv(),buku36);
                bukus.put(buku37.getNoInv(),buku37);
                bukus.put(buku38.getNoInv(),buku38);
                bukus.put(buku39.getNoInv(),buku39);
                bukus.put(buku40.getNoInv(),buku40);

                //Sejarah
                Data.Buku buku41 = data.new Buku();
                Data.Buku buku42 = data.new Buku();
                Data.Buku buku43 = data.new Buku();
                Data.Buku buku44 = data.new Buku();
                Data.Buku buku45 = data.new Buku();
            buku41.setJudulBuku ("Ancient Africa: A Global History, to 300 CE")
                .setPenulis ("Christopher Ehret")
                .setKlasifikasi (9)
                .setNoInv("9.1")
                .setTersedia (true);
            buku42.setJudulBuku ("Pax: War and Peace in Rome’s Golden Age")
                .setPenulis ("Tom Holland")
                .setKlasifikasi (9)
                .setNoInv("9.2")
                .setTersedia (true);
            buku43.setJudulBuku ("Witchcraft: A History in Thirteen Trials")
                .setPenulis ("Marion Gibson")
                .setKlasifikasi (9)
                .setNoInv("9.3")
                .setTersedia (true);
            buku44.setJudulBuku ("The Earth Transformed: An Untold History")
                .setPenulis ("Peter Frankopan")
                .setKlasifikasi (9)
                .setNoInv("9.4")
                .setTersedia (true);
            buku45.setJudulBuku ("The World: A Family History of Humanity")
                .setPenulis ("Simon Sebag Montefiore")
                .setKlasifikasi (9)
                .setNoInv("9.5")
                .setTersedia (true);
                bukus.put(buku41.getNoInv(),buku41);
                bukus.put(buku42.getNoInv(),buku42);
                bukus.put(buku43.getNoInv(),buku43);
                bukus.put(buku44.getNoInv(),buku44);
                bukus.put(buku45.getNoInv(),buku45);

    }                
        
    public void login(Scanner scanner) {
            Peminjam peminjam1 = new Peminjam();
            Peminjam peminjam2 = new Peminjam();
            peminjam1.setNama("Aldi").setUserName("aldikeren").setPassword("12345");
            peminjam2.setNama("Omar").setUserName("omar123").setPassword("54321");
                
                // Menggunakan getUserName() sebagai kunci
            peminjams.put(peminjam1.getUserName(), peminjam1);
            peminjams.put(peminjam2.getUserName(), peminjam2);
                
            Admin admin = new Admin();
            admin.setNama("uinbdg").setUserName("uinsgd23").setPassword("22222");
                
                // Menggunakan getUserName() sebagai kunci
            admins.put(admin.getUserName(), admin);
            
        System.out.print("Masukkan nama: ");
        String nama = scanner.nextLine();
        System.out.print("Masukkan username: ");
        String username = scanner.nextLine();
        System.out.print("Masukkan kata sandi: ");
        String password = scanner.nextLine();
    
        // Cek apakah pengguna adalah peminjam atau admin
        if (peminjams.containsKey(username) && peminjams.get(username).getPassword().equals(password) && peminjams.get(username).getNama().equals(nama)) {
            peminjamAktif = peminjams.get(username);
            menuPeminjam(scanner);
        } else if (admins.containsKey(username) && admins.get(username).getPassword().equals(password) && admins.get(username).getNama().equals(nama)) {
            menuAdmin(scanner);
        } else {
            System.out.println("Nama pengguna atau kata sandi salah. Silakan coba lagi.");
        }
    }
    
    public static void login(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PerpusController perpusController = new PerpusController();

        // Menambahkan contoh peminjam dan admin
        perpusController.peminjams.put("peminjam1", new Peminjam());
        perpusController.admins.put("admin1", new Admin());

        perpusController.login(scanner);
    }

    // Menu utama untuk peminjam
    public void menuPeminjam(Scanner scanner) {
        int pilihan;
        do {
            System.out.println("\n=== MENU PEMINJAM ===");
            System.out.println("1. Daftar Buku");
            System.out.println("2. Pinjam Buku");
            System.out.println("3. Logout");
            System.out.print("Pilihan Anda: ");
            pilihan = scanner.nextInt();
            scanner.nextLine(); // Membersihkan buffer

            switch (pilihan) {
                case 1:
                    dataBuku(null);
                    break;
                case 2:
                    pinjamBuku(scanner);
                    break;
                case 3:
                    peminjamAktif = null; // Logout peminjam
                    System.out.println("\nSelamat Tinggal");
                    System.out.println("Terima Kasih Telah Berkunjung <3");
                    break;

                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (pilihan != 3);
    }

    public static void dataBuku(String[] args) {
        PerpusController perpusController = new PerpusController();

        // Menambahkan contoh buku
        perpusController.bookList();

        // Memanggil metode untuk menampilkan klasifikasi buku dan buku berdasarkan klasifikasi
        perpusController.tampilkanBukuDenganKlasifikasi();
    }

    // Menampilkan klasifikasi buku, meminta input dari pengguna, dan menampilkan buku berdasarkan klasifikasi yang dipilih
    public void tampilkanBukuDenganKlasifikasi() {
        tampilkanKlasifikasi();
        
        // Pilih klasifikasi yang ingin ditampilkan
        System.out.print("\nPilih klasifikasi buku (masukkan angka): ");
        int pilihanKlasifikasi = scanner.nextInt();


        tampilkanBukuByKlasifikasi(pilihanKlasifikasi);
    }

    // Menampilkan klasifikasi buku
    public void tampilkanKlasifikasi() {
        System.out.println("=== KLASIFIKASI BUKU ===");
        klasifikasiMap.put(1, "Karya Umum");
        klasifikasiMap.put(2, "Filsafat");
        klasifikasiMap.put(3, "Ilmu Sosial");
        klasifikasiMap.put(4, "Bahasa");
        klasifikasiMap.put(5, "Ilmu Murni");
        klasifikasiMap.put(6, "Pengetahuan Praktis");
        klasifikasiMap.put(7, "Kesenian dan Hiburan");
        klasifikasiMap.put(8, "Kesusastraan");
        klasifikasiMap.put(9, "Sejarah");

        for (Map.Entry<Integer, String> entry : klasifikasiMap.entrySet()) {
            int klasifikasi = entry.getKey();
            String keterangan = entry.getValue();
            System.out.println(klasifikasi + ". " + keterangan);
        }
    }

    // Menampilkan daftar buku berdasarkan klasifikasi
    public void tampilkanBukuByKlasifikasi(int klasifikasi) {
        System.out.println();
        System.out.println("=== DAFTAR BUKU (" + klasifikasiMap.get(klasifikasi) + ") ===");
        for (Map.Entry<String, Buku> buku : bukus.entrySet()) {
            Buku tBuku = buku.getValue();
            if (tBuku.getKlasifikasi() == klasifikasi && tBuku.getTersedia()) {
                System.out.println("Nama \t\t :" + tBuku.getjudulBuku());
                System.out.println("No. Inventaris \t :" + tBuku.getNoInv());
                System.out.println();
            }
        }
    }

    // ... (Fungsi lain tetap sama)
    public void pinjamBuku(Scanner scanner) {
        System.out.print("Masukkan noInv buku yang ingin dipinjam: ");
        String noInv = scanner.nextLine();
    
        Buku buku = bukus.get(noInv);
        if (buku != null) {
            if (buku.getTersedia()) {
                // Cek apakah peminjam sudah meminjam buku tersebut
                if (!peminjamAktif.sudahMeminjam(buku)) {
                    LocalDate tanggalPinjam = LocalDate.now();
                    LocalDate tanggalPengembalian = tanggalPinjam.plusDays(7);
                    Peminjaman peminjaman = new Peminjaman(peminjamAktif, buku, tanggalPinjam, tanggalPengembalian);
                    peminjamAktif.tambahBukuDipinjam(peminjaman);
                    buku.setTersedia(false);
                    peminjamans.add(peminjaman);
                    System.out.println("\n== BUKU YANG DIPINJAM ==");
                    System.out.println("Judul Buku: " + buku.getjudulBuku());
                    System.out.println("Penulis\t: " + buku.getPenulis());
                    System.out.println("No Inventaris \t: " + buku.getNoInv());
                    System.out.println("\nBuku berhasil dipinjam.");
                } else {
                    System.out.println("\nAnda sudah meminjam buku ini sebelumnya.");
                }
            } else {
                System.out.println("Buku tidak tersedia.");
            }
        } else {
            System.out.println("Nomor inventaris tidak valid.");
        }
    }

    // Fungsi untuk admin
    public void menuAdmin(Scanner scanner) {
        int pilihan;
        do {
            System.out.println("\n=== MENU ADMIN ===");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Hapus Buku");
            System.out.println("3. Cek Buku Dipinjam");
            System.out.println("4. Konfirmasi Pengembalian");
            System.out.println("5. Logout");
            System.out.print("Pilihan Anda: ");
            pilihan = scanner.nextInt();
            scanner.nextLine(); // Membersihkan buffer

            switch (pilihan) {
                case 1:
                    tambahBuku(scanner);
                    break;
                case 2:
                    hapusBuku(scanner);
                    break;
                case 3:
                    cekBukuDipinjam(scanner);
                    break;
                case 4:
                    konfirmasiPengembalian(scanner);
                    break;
                case 5:
                    // Logout admin
                    System.out.println("\nSelamat Tinggal");
                    System.out.println("Terima Kasih Telah Berkunjung <3");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        } while (pilihan != 5);
    }

    // ... (Fungsi lain tetap sama)

    public void konfirmasiPengembalian(Scanner scanner) {
        System.out.print("Masukkan noInv buku yang ingin dikembalikan: ");
        String noInv = scanner.nextLine();
    
        // Cek apakah buku dengan nomor inventaris tersebut memang sedang dipinjam
        boolean bukuDipinjam = false;
        for (Peminjaman peminjaman : peminjamans) {
            if (peminjaman.getBuku().getNoInv().equals(noInv)) {
                bukuDipinjam = true;
                // Lakukan proses konfirmasi pengembalian sesuai kebutuhan
                // Misalnya, set buku menjadi tersedia, hapus data peminjaman, dll.
                // ...
                System.out.println("Buku berhasil dikembalikan.");
                break;
            }  
        }
        if (!bukuDipinjam) {
            System.out.println("Buku dengan nomor inventaris " + noInv + " tidak sedang dipinjam.");
        }
    
    }

    public void cekBukuDipinjam(Scanner scanner) {
        System.out.print("Masukkan noInv buku yang ingin dicek: ");
        String noInv = scanner.nextLine();
    
        // Cek apakah buku dengan nomor inventaris tersebut sedang dipinjam
        boolean bukuDipinjam = false;
        for (Peminjaman peminjaman : peminjamans) {
            if (peminjaman.getBuku().getNoInv().equals(noInv)) {
                bukuDipinjam = true;
                // Tampilkan informasi peminjaman buku
                System.out.println("Buku dengan nomor inventaris " + noInv + " sedang dipinjam oleh " + peminjaman.getPeminjam().getNama());
                System.out.println("Tanggal Peminjaman: " + peminjaman.getTanggalPeminjaman());
                System.out.println("Tanggal Pengembalian: " + peminjaman.getTanggalPengembalian());
                break;
            }
        }
    
        if (!bukuDipinjam) {
            System.out.println("Buku dengan nomor inventaris " + noInv + " tidak sedang dipinjam.");
        }
    }

    public void hapusBuku(Scanner scanner) {
        System.out.print("Masukkan noInv buku yang ingin dihapus: ");
        String noInv = scanner.nextLine();
    
        // Cek apakah buku dengan nomor inventaris tersebut ada dalam daftar buku
        if (bukus.containsKey(noInv)) {
            // Hapus buku dari daftar buku
            bukus.remove(noInv);
            System.out.println("Buku dengan nomor inventaris " + noInv + " berhasil dihapus.");
        } else {
            System.out.println("Buku dengan nomor inventaris " + noInv + " tidak ditemukan.");
        }
    }

    // Fungsi untuk menambah buku oleh admin
    public void tambahBuku(Scanner scanner) {
        System.out.print("Masukkan judul buku: ");
        String judulBuku = scanner.nextLine();
        System.out.print("Masukkan penulis buku: ");
        String penulis = scanner.nextLine();
        System.out.print("Masukkan klasifikasi buku (masukkan angka): ");
        int klasifikasi = scanner.nextInt();
        scanner.nextLine(); // Membersihkan buffer

        Data.Buku buku = new Data().new Buku();
        buku.setJudulBuku(judulBuku)
            .setPenulis(penulis)
            .setKlasifikasi(klasifikasi)
            .setTersedia(true);

        bukus.put(buku.getNoInv(), buku);
        System.out.println("Buku berhasil ditambahkan.");
    }

    // ... (Fungsi lain tetap sama)


}

        // ...

    
