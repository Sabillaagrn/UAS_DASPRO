package model;
public class Admin extends Akun {
    private String akunAdmin;
    
    public Admin setAkunAdmin(String akunAdmin){
        this.akunAdmin = akunAdmin;
        return this;
    }
    public String getAkunAdmin(){
        return this.akunAdmin;
    }

}