package model;
public class Akun {

    private String nama;
    private String username;
    private String password;

    public Akun setNama(String nama) {
        this.nama = nama;
        return this;
    }

    public String getNama() {
        return this.nama;
    }

    public Akun setUserName(String username) {
        this.username = username;
        return this;
    }

    public String getUserName() {
        return this.username;
    }

    public Akun setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getPassword() {
        return this.password;
    }
}