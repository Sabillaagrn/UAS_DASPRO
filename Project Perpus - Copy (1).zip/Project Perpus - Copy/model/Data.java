package model;

import java.time.LocalDateTime;

public class Data {
    /**
     * Buku
     */
    public class Buku {
        private String judulBuku;
        private String penulis;
        private int klasifikasi;
        private String noInv;
        private boolean tersedia;
        
        public Buku setJudulBuku (String judulBuku){
            this.judulBuku = judulBuku;
            return this;
        }

        public String getjudulBuku (){
            return this.judulBuku;
        }

        public Buku setPenulis (String penulis){
            this.penulis = penulis;
            return this;
        }

        public String getPenulis (){
            return this.penulis;
        }

        public Buku setKlasifikasi (int klasifikasi){
            this.klasifikasi = klasifikasi;
            return this;
        }

        public int getKlasifikasi (){
            return this.klasifikasi;
        }

        public Buku setNoInv (String noInv){
            this.noInv = noInv;
            return this;
        }

        public String getNoInv (){
            return this.noInv;
        }
        
        public Buku setTersedia (boolean tersedia){
            this.tersedia = tersedia;
            return this;
        }

        public boolean getTersedia (){
            return this.tersedia;
        }
    }

    /**
     * Waktu Peminjaman
     */
    public class Waktu {
        private LocalDateTime waktuPinjam;
        private LocalDateTime waktuKembali;

        public Waktu setWaktuPinjam (LocalDateTime waktuPinjam){
            this.waktuPinjam = waktuPinjam;
            return this;
        }

        public LocalDateTime getWaktuPinjam (){
            return this.waktuPinjam;
        }

            public Waktu setWaktuKembali (LocalDateTime waktuKembali){
            this.waktuKembali = waktuKembali;
            return this;
        }

             public LocalDateTime getWaktuKembali (){
            return this.waktuKembali;
        }

    }
}