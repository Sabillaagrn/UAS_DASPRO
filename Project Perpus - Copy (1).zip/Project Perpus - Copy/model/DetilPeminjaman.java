package model;

import java.time.LocalDate;
import model.Data.Buku;

public class DetilPeminjaman {
    private String idPeminjaman;
    private Peminjaman peminjaman;
    private Buku buku;
    private int jumlahPinjam;
    private LocalDate waktu;

    /**
     * @return String return the idPeminjaman
     */
    public String getIdPeminjaman() {
        return idPeminjaman;
    }

    /**
     * @param idPeminjaman the idPeminjaman to set
     */
    public void setIdPeminjaman(String idPeminjaman) {
        this.idPeminjaman = idPeminjaman;
    }

    /**
     * @return Peminjaman return the peminjaman
     */
    public Peminjaman getPeminjaman() {
        return peminjaman;
    }

    /**
     * @param peminjaman the peminjaman to set
     */
    public void setPeminjaman(Peminjaman peminjaman) {
        this.peminjaman = peminjaman;
    }

    /**
     * @return Buku return the buku
     */
    public Buku getBuku() {
        return buku;
    }

    /**
     * @param buku the buku to set
     */
    public void setBuku(Buku buku) {
        this.buku = buku;
    }

    /**
     * @return int return the jumlahPinjam
     */
    public int getJumlahPinjam() {
        return jumlahPinjam;
    }

    /**
     * @param jumlahPinjam the jumlahPinjam to set
     */
    public void setJumlahPinjam(int jumlahPinjam) {
        this.jumlahPinjam = jumlahPinjam;
    }

    /**
     * @return LocalDate return the waktu
     */
    public LocalDate getWaktu() {
        return waktu;
    }

    /**
     * @param waktu the waktu to set
     */
    public void setWaktu(LocalDate waktu) {
        this.waktu = waktu;
    }
}
