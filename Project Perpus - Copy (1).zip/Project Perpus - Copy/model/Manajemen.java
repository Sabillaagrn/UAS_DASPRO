package model;

import java.util.ArrayList;
import java.time.LocalDateTime;

public class Manajemen {
    private String idPeminjaman;
    private Admin admin;
    private int total;
    private LocalDateTime tanggalPeminjaman;
    private LocalDateTime tanggalPengembalian;
    private ArrayList<DetilPeminjaman> detilPeminjamans;

    public Manajemen setIdPeminjaman(String idPeminjaman){
        this.idPeminjaman = idPeminjaman;
        return this;
    }

    public String getIdPeminjaman(){
        return this.idPeminjaman;
    }

    public Manajemen setAdmin(Admin admin){
        this.admin = admin;
        return this;
    }

    public Admin setAdmin(){
        return this.admin;
    }

    public Manajemen setTotal(int total){
        this.total = total;
        return this;
    }

    public int getTotal(){
        return this.total;
    }

    public Manajemen setTanggalPeminjaman(LocalDateTime tanggalPeminjaman){
        this.tanggalPeminjaman = tanggalPeminjaman;
        return this;
    }

    public LocalDateTime getTanggalPeminjaman(){
        return this.tanggalPeminjaman;
    }

    
    public Manajemen setTanggalPengembalian(LocalDateTime tanggalPengembalian){
        this.tanggalPengembalian = tanggalPengembalian;
        return this;
    }

    public LocalDateTime getTanggalPengembalian(){
        return this.tanggalPengembalian;
    }

    public Manajemen setDetilPeminjamans(ArrayList<DetilPeminjaman> detilPeminjamans){
        this.detilPeminjamans = detilPeminjamans;
        return this;
    }

    public ArrayList<DetilPeminjaman> getDetilPeminjamans(){
        return this.detilPeminjamans;
    }
}
