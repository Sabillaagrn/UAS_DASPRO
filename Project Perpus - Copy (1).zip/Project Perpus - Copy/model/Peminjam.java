package model;
import java.util.ArrayList;
import java.util.List;

import model.Data.Buku;
public class Peminjam extends Akun {
    private String idPeminjam;
    private ArrayList<DetilPeminjaman> detilPeminjamans;

    private List<Peminjaman> bukuDipinjam;
    
    public Peminjam() {
        this.bukuDipinjam = new ArrayList<>();
        }

    public List<Peminjaman> getBukuDipinjam() {
            return this.bukuDipinjam;
        }

    public void tambahDetilPeminjaman(DetilPeminjaman detilPeminjaman) {
        this.detilPeminjamans.add(detilPeminjaman);
    }

    public ArrayList<DetilPeminjaman> getDetilPeminjamans() {
        return this.detilPeminjamans;
    }

    

    public Peminjam setIdPeminjam(String idPeminjam){
        this.idPeminjam = idPeminjam;
        return this;
    }
    public String getIdPeminjam(){
        return this.idPeminjam;
    }

    public void tambahBukuDipinjam(Peminjaman peminjaman) {
    }

    public boolean sudahMeminjam(Buku buku) {
        return false;
    }
}