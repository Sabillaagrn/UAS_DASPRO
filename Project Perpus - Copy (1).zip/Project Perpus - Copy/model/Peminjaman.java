package model;

import java.time.LocalDate;
import java.util.ArrayList;

import model.Data.Buku;

public class Peminjaman {
    private String idPeminjaman;
    private Peminjam peminjam;
    private int total;
    private LocalDate tanggalPeminjaman;
    private LocalDate tanggalPengembalian;
    private ArrayList<DetilPeminjaman> detilPeminjamans;


    public Peminjaman(Peminjam peminjamAktif, Buku buku, LocalDate tanggalPinjam, LocalDate tanggalPengembalian2) {
    }


    public String getIdPenjualan() {
        return idPeminjaman;

    }

     
    public Peminjam getPeminjam() {
        return peminjam;
    }

    
    public Peminjaman setPeminjam(Peminjam peminjam) {
        this.peminjam = peminjam;
        return this;
    }

   
    public int getTotal() {
        return total;
    }


    public Peminjaman setTotal(int total) {
        this.total = total;
        return this;
    }

   
    public LocalDate getTanggalPeminjaman() {
        return tanggalPeminjaman;
    }

   
    public Peminjaman setTanggalPeminjaman(LocalDate tanggalPeminjaman) {
        this.tanggalPeminjaman = tanggalPeminjaman;
        return this;
    }

     public LocalDate getTanggalPengembalian() {
        return tanggalPeminjaman;
    }

   
    public Peminjaman setTanggalPengembalian(LocalDate tanggalPengembalian) {
        this.tanggalPengembalian = tanggalPengembalian;
        return this;
    }


   
    public ArrayList<DetilPeminjaman> getDetilPeminjaman() {
        return detilPeminjamans;
    }

    public Peminjaman setDetilPenjualans(ArrayList<DetilPeminjaman> detilPeminjamans) {
        this.detilPeminjamans = detilPeminjamans;
        return this;
    }


    public Buku getBuku() {
        return null;
    }


}
